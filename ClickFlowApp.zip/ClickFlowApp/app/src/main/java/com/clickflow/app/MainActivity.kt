package com.clickflow.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(60, 60, 60, 60)
        }

        val title = TextView(this).apply {
            text = "ClickFlow setup"
            textSize = 22f
            setPadding(0, 0, 0, 40)
        }

        val step1 = Button(this).apply {
            text = "1. Allow \"display over other apps\""
            setOnClickListener {
                startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                )
            }
        }

        val step2 = Button(this).apply {
            text = "2. Turn on ClickFlow Accessibility Service"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }

        val step3 = Button(this).apply {
            text = "3. Start floating overlay"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(
                        Intent(
                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:$packageName")
                        )
                    )
                } else {
                    startService(Intent(this@MainActivity, OverlayService::class.java))
                }
            }
        }

        val note = TextView(this).apply {
            text = "Do steps 1 and 2 once. Then step 3 shows the floating panel " +
                "on top of any app. Minimize this screen after that."
            setPadding(0, 40, 0, 0)
            textSize = 12f
        }

        layout.addView(title)
        layout.addView(step1)
        layout.addView(step2)
        layout.addView(step3)
        layout.addView(note)
        setContentView(layout)
    }
}
