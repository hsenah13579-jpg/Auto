package com.clickflow.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent

/**
 * Watches the screen for content/window changes to guess when a page has
 * "finished loading" (no new events for ~1.2s), and dispatches real tap
 * gestures at the saved clicker coordinates in a loop.
 */
class ClickAccessibilityService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    private var loopIndex = 0
    private var lastEventTime = 0L
    private var loopToken: Any? = null

    private val loadCheckRunnable = object : Runnable {
        override fun run() {
            val idleFor = System.currentTimeMillis() - lastEventTime
            AutomationState.pageReady = idleFor > 1200
            handler.postDelayed(this, 400)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        lastEventTime = System.currentTimeMillis()
        handler.post(loadCheckRunnable)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Any window or content change resets the "settled" timer.
        lastEventTime = System.currentTimeMillis()
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        super.onDestroy()
        instance = null
        handler.removeCallbacksAndMessages(null)
    }

    fun startLoop() {
        loopIndex = 0
        AutomationState.isRunning = true
        stepLoop()
    }

    fun stopLoop() {
        AutomationState.isRunning = false
        handler.removeCallbacksAndMessages(null)
        handler.post(loadCheckRunnable) // keep the load-watcher alive
    }

    private fun stepLoop() {
        if (!AutomationState.isRunning || AutomationState.points.isEmpty()) return
        val p = AutomationState.points[loopIndex % AutomationState.points.size]
        performClick(p.x, p.y)
        loopIndex++
        handler.postDelayed({ stepLoop() }, 700)
    }

    private fun performClick(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 50))
            .build()
        dispatchGesture(gesture, null, null)
    }

    companion object {
        var instance: ClickAccessibilityService? = null
    }
}
