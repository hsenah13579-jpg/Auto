package com.clickflow.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.res.Resources
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.PointF
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

class OverlayService : Service() {

    private lateinit var wm: WindowManager
    private var panelView: View? = null
    private var catcherView: View? = null
    private val clickerViews = mutableListOf<View>()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        startForegroundServiceCompat()
        addPanel()
    }

    override fun onDestroy() {
        super.onDestroy()
        AutomationState.isRunning = false
        panelView?.let { runCatching { wm.removeView(it) } }
        catcherView?.let { runCatching { wm.removeView(it) } }
        clickerViews.forEach { runCatching { wm.removeView(it) } }
    }

    private fun startForegroundServiceCompat() {
        val channelId = "clickflow_channel"
        val mgr = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        val channel = NotificationChannel(channelId, "ClickFlow", NotificationManager.IMPORTANCE_LOW)
        mgr.createNotificationChannel(channel)
        val notification = Notification.Builder(this, channelId)
            .setContentTitle("ClickFlow running")
            .setContentText("Floating overlay is active")
            .setSmallIcon(android.R.drawable.ic_menu_send)
            .build()
        startForeground(1, notification)
    }

    private fun overlayType() = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY

    // ---------- floating control panel ----------

    private fun addPanel() {
        val ctx = this

        val panel = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#EE16211D"))
            setPadding(28, 28, 28, 28)
        }

        val title = TextView(ctx).apply {
            text = "ClickFlow"
            setTextColor(Color.WHITE)
            textSize = 15f
        }

        val status = TextView(ctx).apply {
            text = "watching for page load…"
            setTextColor(Color.parseColor("#9BB0A6"))
            textSize = 11f
            setPadding(0, 12, 0, 0)
        }

        val row1 = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        val addBtn = Button(ctx).apply {
            text = "+"
            setOnClickListener {
                status.text = "tap the screen to place clicker #${AutomationState.points.size + 1}"
                showTouchCatcher()
            }
        }
        val removeBtn = Button(ctx).apply {
            text = "−"
            setOnClickListener {
                if (AutomationState.points.isNotEmpty() && clickerViews.isNotEmpty()) {
                    AutomationState.points.removeAt(AutomationState.points.size - 1)
                    val v = clickerViews.removeAt(clickerViews.size - 1)
                    runCatching { wm.removeView(v) }
                    status.text = "${AutomationState.points.size} clicker(s) queued"
                }
            }
        }
        row1.addView(addBtn)
        row1.addView(removeBtn)

        val clipInput = EditText(ctx).apply {
            hint = "text to paste on click"
            setTextColor(Color.WHITE)
            setHintTextColor(Color.parseColor("#617266"))
        }
        val row2 = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        val copyBtn = Button(ctx).apply {
            text = "Copy"
            setOnClickListener {
                val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("clickflow", clipInput.text.toString()))
                AutomationState.clipText = clipInput.text.toString()
            }
        }
        val pasteBtn = Button(ctx).apply {
            text = "Paste"
            setOnClickListener {
                val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                val txt = cm.primaryClip?.getItemAt(0)?.text?.toString() ?: ""
                clipInput.setText(txt)
            }
        }
        row2.addView(copyBtn)
        row2.addView(pasteBtn)

        val runBtn = Button(ctx).apply {
            text = "Start loop"
            setOnClickListener {
                if (!AutomationState.isRunning) {
                    if (!AutomationState.pageReady) {
                        status.text = "still waiting on page load…"
                        return@setOnClickListener
                    }
                    if (AutomationState.points.isEmpty()) {
                        status.text = "add at least one clicker first"
                        return@setOnClickListener
                    }
                    ClickAccessibilityService.instance?.startLoop()
                    text = "Stop loop"
                    status.text = "looping through ${AutomationState.points.size} point(s)…"
                } else {
                    ClickAccessibilityService.instance?.stopLoop()
                    text = "Start loop"
                    status.text = "page loaded — ready to click"
                }
            }
        }

        panel.addView(title)
        panel.addView(row1)
        panel.addView(clipInput)
        panel.addView(row2)
        panel.addView(runBtn)
        panel.addView(status)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 40
            y = 160
        }

        makeDraggable(panel, params)
        wm.addView(panel, params)
        panelView = panel
    }

    // ---------- placing a numbered clicker marker ----------

    private fun showTouchCatcher() {
        if (catcherView != null) return
        val catcher = View(this)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        catcher.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_DOWN) {
                addClickerMarker(event.rawX, event.rawY)
                runCatching { wm.removeView(catcher) }
                catcherView = null
            }
            true
        }
        wm.addView(catcher, params)
        catcherView = catcher
    }

    private fun addClickerMarker(x: Float, y: Float) {
        if (AutomationState.points.size >= 10) return
        val num = AutomationState.points.size + 1

        val marker = TextView(this).apply {
            text = num.toString()
            setTextColor(Color.parseColor("#4CE0A3"))
            setBackgroundColor(Color.parseColor("#16211D"))
            textSize = 15f
            gravity = Gravity.CENTER
        }

        val size = (44 * Resources.getSystem().displayMetrics.density).toInt()
        val params = WindowManager.LayoutParams(
            size, size, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            this.x = (x - size / 2).toInt()
            this.y = (y - size / 2).toInt()
        }

        val index = clickerViews.size
        makeDraggable(marker, params) { newX, newY ->
            if (index < AutomationState.points.size) {
                AutomationState.points[index] = PointF(newX + size / 2f, newY + size / 2f)
            }
        }

        wm.addView(marker, params)
        clickerViews.add(marker)
        AutomationState.points.add(PointF(x, y))
    }

    // ---------- shared drag handler for panel + markers ----------

    private fun makeDraggable(
        view: View,
        params: WindowManager.LayoutParams,
        onMoved: ((Int, Int) -> Unit)? = null
    ) {
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        view.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x
                    startY = params.y
                    touchX = event.rawX
                    touchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = startX + (event.rawX - touchX).toInt()
                    params.y = startY + (event.rawY - touchY).toInt()
                    runCatching { wm.updateViewLayout(view, params) }
                    onMoved?.invoke(params.x, params.y)
                    true
                }
                else -> false
            }
        }
    }
}
