package com.clickflow.app

import android.graphics.PointF

/**
 * Shared in-memory state between the floating overlay (OverlayService)
 * and the accessibility service that actually performs the taps
 * (ClickAccessibilityService). Both run in the same app process.
 */
object AutomationState {
    val points = mutableListOf<PointF>()
    var isRunning = false
    var clipText: String = ""
    var pageReady = false
}
