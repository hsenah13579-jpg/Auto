# ClickFlow — Android floating auto-clicker

Real Android app: floating overlay panel, numbered clicker points (1–10, looping),
copy/paste clipboard, and an accessibility-service that waits for the screen to
settle ("page loaded") before dispatching real taps.

## মোবাইল থেকেই কীভাবে বিল্ড করবেন (কোনো ডেস্কটপ লাগবে না)

**ধাপ ১ — GitHub-এ রিপো বানান**
1. মোবাইলে GitHub app বা browser দিয়ে github.com-এ একটা নতুন **public repository** বানান (নাম যা খুশি, যেমন `clickflow`)
2. এই পুরো ফোল্ডারের সব ফাইল সেই রিপোতে আপলোড করুন — GitHub-এর ওয়েব ইন্টারফেসেই "Add file → Upload files" দিয়ে পুরো ফোল্ডার/ফাইলগুলো টেনে দিন (ফোল্ডার স্ট্রাকচার ঠিক রেখে)

**ধাপ ২ — Actions চালু করুন**
1. রিপোর **Actions** ট্যাবে যান
2. "Build APK" workflow-টা দেখাবে — **Run workflow** বাটনে ট্যাপ করুন
3. ২-৩ মিনিট পর বিল্ড শেষ হবে (সবুজ ✓ চিহ্ন দেখাবে)

**ধাপ ৩ — APK ডাউনলোড করুন**
1. শেষ হওয়া workflow run-এ ট্যাপ করুন
2. নিচে **Artifacts** সেকশনে `clickflow-debug-apk` দেখাবে — সেটা ডাউনলোড করুন (zip হিসেবে আসবে, ভেতরে `.apk` ফাইল)
3. zip থেকে বের করে `.apk` ফাইলটা ওপেন করুন — ফোন "Install from unknown sources" চাইতে পারে, allow করে দিন

**ধাপ ৪ — অ্যাপ চালু করার পর**
1. অ্যাপ খুলে বাটন ১ ট্যাপ করে **"Display over other apps"** পারমিশন দিন
2. বাটন ২ ট্যাপ করে Accessibility সেটিংসে গিয়ে **ClickFlow** সার্ভিসটা চালু করুন
3. বাটন ৩ ট্যাপ করলেই ফ্লোটিং প্যানেল যেকোনো অ্যাপের উপর ভেসে উঠবে

## সতর্কতা
- এটা device-level sensitive পারমিশন ব্যবহার করে (overlay + accessibility) — শুধু নিজের ফোনে, নিজের প্রয়োজনে ব্যবহার করুন
- এটা একটা কার্যকরী স্ক্যাফোল্ড/starting point — আপনি নিজের মতো UI, স্পিড, বা ফিচার পরে বাড়াতে পারবেন
- Play Store-এ পাবলিশ করতে গেলে accessibility service নীতিমালা মেনে অতিরিক্ত justification লাগবে
